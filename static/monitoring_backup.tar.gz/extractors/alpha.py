#!/home/ufk/ufk_venv/bin/python
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

import django
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "monitoring_project.settings")
django.setup()

from datetime import datetime, timezone
import pytz
localtime = pytz.timezone("Asia/Krasnoyarsk")

from fake_useragent import UserAgent
fua = UserAgent(verify_ssl=False)

from monitoring.models import UK, PIF
from django.db.models import Q

alpha = UK.objects.filter(uk_ogrn = '1027739292283').first()
pifset = PIF.objects.filter(Q(pif_uk = alpha) & ~Q(pif_checkpage=''))

headers = {'User-Agent': fua.random}

from bs4 import BeautifulSoup
import re

def getcontents(url, sub=False):

    response = requests.get(url, headers=headers, verify=False)
    html = response.content

    soup = BeautifulSoup(html, 'html.parser')
    
    curtagitem = soup.select("div#app nav.root li:not(:has(a))")
    curitem = curtagitem[0].string
    
    sibarray = [] 
    elemarray = []

    for tag in soup.select('div#app section main div.root'):
        
        link = tag.select_one('a')
        if link is not None:
            href = link['href']
        
        if tag.select_one('div.content div') is not None:
            text = tag.select_one('div.content div').string

        date = tag.find('span', string=re.compile('\d{2}.\d{2}.\d{4}'))
        if date is not None:
            elemarray.append([text, date.string, href])

    if len(elemarray) > 0:
        sibarray.append([curitem, elemarray])

    if not sub:
        menu = soup.select("div#app nav.root li a")
        for item in menu:
            if len(re.findall(r'disclosure', item['href'])) > 0:
                sibarray = sibarray + getcontents(url[:url.find('/disclosure')] + item['href'], True)
    
    return sibarray

alphacheck = open('/home/ufk/monitoring_project/templates/alpha.html', 'w')

for pif in pifset:
    content = getcontents(pif.pif_checkpage)
    alphacheck.write('<div class="container">')
    alphacheck.write('<h3>{}</h3><a href="{}">{}</a>'.format(pif.pif_shortname, pif.pif_checkpage, pif.pif_checkpage))
    for e in content:
        if len(e) > 0:
            alphacheck.write('<h5>{}</h5>'.format(e[0]))
        #for k in e[1]:
            if len(e[1]) > 0:
                alphacheck.write('<div class="d-flex flex-wrap justify-content-between">')
                alphacheck.write('<a href=\"{}\">{}</a><p><b>{}</b>'.format(pif.pif_uk.uk_sitetype + '://' + pif.pif_uk.uk_site + e[1][0][2], e[1][0][0], e[1][0][1]))
                alphacheck.write('</div>')
    alphacheck.write('</div>')
alphacheck.close()
